const rupees = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

const screeningDate = new Intl.DateTimeFormat('en-IN', {
  weekday: 'short',
  day: 'numeric',
  month: 'short',
  hour: 'numeric',
  minute: '2-digit',
});

const bookingDate = new Intl.DateTimeFormat('en-IN', {
  dateStyle: 'medium',
  timeStyle: 'short',
});

export function formatCurrency(amount: number) {
  return rupees.format(amount);
}

export function formatShowtime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : screeningDate.format(date);
}

export function formatBookingDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : bookingDate.format(date);
}
