import type { ReactNode } from 'react';
import { Link } from 'wouter';
import { ArrowUpRight, Clapperboard } from 'lucide-react';

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href="/" className="brand" data-testid="link-home">
          <span className="brand-mark"><Clapperboard size={17} strokeWidth={1.8} /></span>
          <span className="brand-name">Marquee</span>
        </Link>
        <Link href="/" className="nav-link" data-testid="link-now-showing">
          Now showing <ArrowUpRight size={15} />
        </Link>
      </header>
      {children}
      <footer className="page-wrap footer">
        <span>Marquee Cinema Club</span>
        <span>Good films. Great nights.</span>
      </footer>
    </div>
  );
}

export function PageWrap({ children }: { children: ReactNode }) {
  return <main className="page-wrap">{children}</main>;
}
