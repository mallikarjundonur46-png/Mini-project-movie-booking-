import { useEffect, useMemo, useState } from 'react';
import { useParams, useLocation, Link } from 'wouter';
import { ArrowLeft, Check, Clock3, LoaderCircle, RotateCw } from 'lucide-react';
import { useCreateBooking, useGetMovieSeats, useListMovies, getGetMovieSeatsQueryKey } from '@workspace/api-client-react';
import type { Seat } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { PageWrap, SiteShell } from '@/components/SiteShell';
import { formatCurrency, formatShowtime } from '@/lib/format';

export default function MoviePage() {
  const params = useParams<{ movieId: string }>();
  const movieId = Number(params.movieId);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const moviesQuery = useListMovies();
  const movie = moviesQuery.data?.find((item) => item.id === movieId);
  const showtimes = movie?.showtimes ?? [];
  const [showtime, setShowtime] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [submitError, setSubmitError] = useState('');
  const seatParams = useMemo(() => ({ showtime }), [showtime]);
  const seatsQuery = useGetMovieSeats(movieId, seatParams, {
    query: { enabled: Number.isFinite(movieId) && movieId > 0 && Boolean(showtime), queryKey: getGetMovieSeatsQueryKey(movieId, seatParams) },
  });
  const booking = useCreateBooking();

  useEffect(() => {
    if (!showtime && showtimes.length) setShowtime(showtimes[0]);
  }, [showtime, showtimes]);
  useEffect(() => { setSelectedSeats([]); }, [showtime]);

  const availableSeats = seatsQuery.data ?? [];
  const selectedTotal = selectedSeats.length * Number(movie?.ticketPrice ?? 0);
  const toggleSeat = (seat: Seat) => {
    if (!seat.available) return;
    setSelectedSeats((current) => current.includes(seat.label) ? current.filter((item) => item !== seat.label) : [...current, seat.label]);
  };
  const submitBooking = () => {
    setSubmitError('');
    if (!customerName.trim() || !showtime || selectedSeats.length === 0) return;
    booking.mutate({ data: { movieId, showtime, customerName: customerName.trim(), seats: selectedSeats } }, {
      onSuccess: (created) => {
        void queryClient.invalidateQueries({ queryKey: getGetMovieSeatsQueryKey(movieId, seatParams) });
        setLocation(`/booking/${encodeURIComponent(created.code)}`);
      },
      onError: () => setSubmitError('That reservation didn’t go through. Your seats are still here — please try again.'),
    });
  };

  if (moviesQuery.isLoading) return <SiteShell><PageWrap><div className="detail-hero"><div className="skeleton" style={{ aspectRatio: '.72' }} /><div><div className="skeleton" style={{ height: 18, width: 110 }} /><div className="skeleton" style={{ height: 70, marginTop: 20 }} /><div className="skeleton" style={{ height: 80, marginTop: 20 }} /></div></div></PageWrap></SiteShell>;
  if (moviesQuery.isError) return <SiteShell><PageWrap><div className="error-state" role="alert"><h3>Couldn’t open the listings.</h3><p>Try loading the film details again.</p><button className="primary-button" onClick={() => void moviesQuery.refetch()} data-testid="button-retry-movie"><RotateCw size={15} /> Try again</button></div></PageWrap></SiteShell>;
  if (!movie) return <SiteShell><PageWrap><div className="empty-state"><h3>That film has left the marquee.</h3><p>It may no longer be available to book.</p><Link href="/" className="primary-button" data-testid="link-back-listings"><ArrowLeft size={15} /> Back to films</Link></div></PageWrap></SiteShell>;

  return (
    <SiteShell>
      <PageWrap>
        <Link href="/" className="nav-link" style={{ marginTop: 27, width: 'fit-content' }} data-testid="link-back-movies"><ArrowLeft size={15} /> All films</Link>
        <section className="detail-hero fade-in">
          <img className="detail-poster" src={movie.posterImage} alt={`${movie.title} poster`} data-testid="img-movie-poster" />
          <div className="detail-copy">
            <div className="eyebrow">One night. One big story.</div>
            <h1 data-testid="text-movie-title">{movie.title}</h1>
            <p data-testid="text-movie-synopsis">{movie.synopsis}</p>
            <div className="detail-facts"><span>{movie.genre}</span><span><Clock3 size={13} style={{ verticalAlign: 'middle', marginRight: 5 }} />{movie.durationMinutes} min</span><span>{formatCurrency(Number(movie.ticketPrice))} / seat</span></div>
          </div>
        </section>
        <div className="booking-layout">
          <section className="booking-panel" aria-label="Choose seats">
            <div className="eyebrow">Make it a movie night</div>
            <h2>Choose your seats</h2>
            <p className="panel-subtitle">First choose a screening, then tap the seats you want.</p>
            <div className="section-note">Screening time</div>
            {showtimes.length ? <div className="time-list">{showtimes.map((time, index) => <button key={`${time}-${index}`} className={`time-choice ${showtime === time ? 'selected' : ''}`} onClick={() => setShowtime(time)} data-testid={`button-showtime-${index}`} aria-pressed={showtime === time}>{formatShowtime(time)}</button>)}</div> : <div className="empty-state" data-testid="status-no-showtimes"><p>No screenings are currently listed for this film.</p></div>}
            {showtime && <div>
              <div className="screen">SCREEN</div>
              {seatsQuery.isLoading && <div className="seat-grid" aria-label="Loading seat availability">{Array.from({ length: 32 }, (_, i) => <div className="skeleton" key={i} style={{ aspectRatio: '1.18', borderRadius: 5 }} />)}</div>}
              {seatsQuery.isError && <div className="error-state" role="alert" data-testid="status-seats-error"><h3>Seat map unavailable.</h3><p>Check availability again before you reserve.</p><button className="outline-button" onClick={() => void seatsQuery.refetch()} data-testid="button-retry-seats"><RotateCw size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />Retry seat map</button></div>}
              {!seatsQuery.isLoading && !seatsQuery.isError && availableSeats.length === 0 && <div className="empty-state" data-testid="status-seats-empty"><h3>No seats left for this show.</h3><p>Try another screening time.</p></div>}
              {!seatsQuery.isLoading && !seatsQuery.isError && availableSeats.length > 0 && <div className="seat-grid" data-testid="grid-seats">{availableSeats.map((seat, index) => {
                const chosen = selectedSeats.includes(seat.label);
                return <button key={`${seat.label}-${index}`} disabled={!seat.available} aria-pressed={chosen} aria-label={`Seat ${seat.label}${seat.available ? chosen ? ', selected' : ', available' : ', unavailable'}`} className={`seat ${!seat.available ? 'unavailable' : ''} ${chosen ? 'chosen' : ''}`} onClick={() => toggleSeat(seat)} data-testid={`button-seat-${seat.label}`}>{seat.label}</button>;
              })}</div>}
              <div className="seat-legend"><span className="legend-item"><i className="legend-dot" />Available</span><span className="legend-item"><i className="legend-dot selected" />Selected</span><span className="legend-item"><i className="legend-dot taken" />Taken</span></div>
            </div>}
            <label className="field-label" htmlFor="customer-name">Booking name</label>
            <input id="customer-name" className="name-input" value={customerName} onChange={(event) => setCustomerName(event.target.value)} placeholder="Name for the tickets" autoComplete="name" data-testid="input-customer-name" />
            {submitError && <p role="alert" data-testid="status-booking-error" style={{ color: '#a90f3e', fontSize: 13 }}>{submitError}</p>}
          </section>
          <aside className="booking-summary" aria-label="Booking summary">
            <div className="summary-label">Your reservation</div>
            <h3>{movie.title}</h3>
            <div className="summary-line"><span>Screening</span><strong data-testid="text-summary-showtime">{showtime || 'Choose a time'}</strong></div>
            <div className="summary-line"><span>Seats</span><strong className="summary-seat" data-testid="text-summary-seats">{selectedSeats.length ? selectedSeats.join(', ') : 'Not selected'}</strong></div>
            <div className="summary-line"><span>Tickets</span><strong>{selectedSeats.length} × {formatCurrency(Number(movie.ticketPrice))}</strong></div>
            <div className="summary-line total-line"><span>Total</span><strong data-testid="text-summary-total">{formatCurrency(selectedTotal)}</strong></div>
            <button className="primary-button summary-button" onClick={submitBooking} disabled={booking.isPending || !customerName.trim() || !showtime || selectedSeats.length === 0 || seatsQuery.isLoading} data-testid="button-reserve-seats">
              {booking.isPending ? <><LoaderCircle size={16} /> Reserving…</> : <><Check size={16} /> Reserve my seats</>}
            </button>
            <p style={{ fontSize: 10, lineHeight: 1.6, color: '#aaa79e', margin: '13px 0 0' }}>Your seats are only held once your reservation is confirmed.</p>
          </aside>
        </div>
      </PageWrap>
    </SiteShell>
  );
}
