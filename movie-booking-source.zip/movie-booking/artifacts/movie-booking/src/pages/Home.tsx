import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { ArrowRight, RotateCw, Search, Ticket } from 'lucide-react';
import { useListMovies } from '@workspace/api-client-react';
import type { Movie } from '@workspace/api-client-react';
import { PageWrap, SiteShell } from '@/components/SiteShell';
import { formatCurrency } from '@/lib/format';

function MovieCard({ movie, index }: { movie: Movie; index: number }) {
  return (
    <article className="movie-card fade-in" style={{ animationDelay: `${index * 75}ms` }} data-testid={`card-movie-${movie.id}`}>
      <Link href={`/movie/${movie.id}`} className="poster-link" data-testid={`link-movie-${movie.id}`}>
        <img src={movie.posterImage} alt={`${movie.title} poster`} data-testid={`img-poster-${movie.id}`} />
        <span className="poster-label">{movie.genre}</span>
      </Link>
      <div className="movie-meta">
        <div><h3 data-testid={`text-title-${movie.id}`}>{movie.title}</h3><div className="movie-sub">{movie.durationMinutes} min · {movie.genre}</div></div>
         <span className="movie-price" data-testid={`text-price-${movie.id}`}>{formatCurrency(Number(movie.ticketPrice))}</span>
      </div>
      <Link href={`/movie/${movie.id}`} className="movie-open" data-testid={`link-book-${movie.id}`}>
        Choose a showtime <ArrowRight size={16} />
      </Link>
    </article>
  );
}

export default function Home() {
  const { data: movies, isLoading, isError, refetch } = useListMovies();
  const [search, setSearch] = useState('');
  const visibleMovies = useMemo(() => (movies ?? []).filter((movie) =>
    `${movie.title} ${movie.genre}`.toLowerCase().includes(search.toLowerCase()),
  ), [movies, search]);
  const featured = movies?.[0];

  return (
    <SiteShell>
      <PageWrap>
        <section className="hero fade-in">
          <div className="hero-copy">
            <div className="eyebrow">Your next night out starts here</div>
            <h1>Meet me<br />at the <em>movies.</em></h1>
            <p className="hero-desc">The lights go down. The world gets bigger. Find the story you want to disappear into tonight.</p>
          </div>
          <div className="hero-art" aria-label={featured ? `Featured film: ${featured.title}` : 'Cinema spotlight'}>
            <div className="hero-glow" />
            {featured?.posterImage && <img className="hero-poster" src={featured.posterImage} alt={`${featured.title} featured poster`} data-testid="img-featured-poster" />}
            <span className="hero-stamp">The big screen<br />is calling</span>
            <span className="hero-caption">CURTAIN UP · TONIGHT</span>
          </div>
        </section>
        <div className="ticker" aria-hidden="true"><span>NOW PLAYING <b>✳</b> PICK YOUR PICTURE <b>✳</b> SAVE YOUR SEAT <b>✳</b> NOW PLAYING <b>✳</b> PICK YOUR PICTURE <b>✳</b></span></div>
        <section aria-labelledby="movies-heading">
          <div className="section-head">
            <div><div className="eyebrow">The current bill</div><h2 id="movies-heading">Now showing</h2></div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, borderBottom: '1px solid #bdb4a5', padding: '8px 1px' }}>
              <Search size={15} color="#777169" />
              <input aria-label="Search films" data-testid="input-search-movies" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Find a film" style={{ border: 0, background: 'transparent', outline: 0, width: 125, font: '12px var(--app-font-sans)' }} />
            </label>
          </div>
          {isLoading && <div className="movie-grid" aria-label="Loading films">{[0,1,2,3].map((item) => <div key={item}><div className="skeleton" style={{ height: 330 }} /><div className="skeleton" style={{ height: 22, marginTop: 14, width: '70%' }} /></div>)}</div>}
          {isError && <div className="error-state" role="alert" data-testid="status-movies-error"><h3>The reels are tangled.</h3><p>We couldn’t load the listings just now.</p><button className="primary-button" onClick={() => void refetch()} data-testid="button-retry-movies"><RotateCw size={15} /> Try again</button></div>}
          {!isLoading && !isError && visibleMovies.length === 0 && <div className="empty-state" data-testid="status-movies-empty"><Ticket size={25} color="#c21c4b" style={{ marginBottom: 15 }} /><h3>{movies?.length ? 'No films match that.' : 'The screen is quiet.'}</h3><p>{movies?.length ? 'Try another title or genre.' : 'There are no films available to book right now. Check back soon.'}</p></div>}
          {!isLoading && !isError && visibleMovies.length > 0 && <div className="movie-grid">{visibleMovies.map((movie, index) => <MovieCard key={movie.id} movie={movie} index={index} />)}</div>}
        </section>
        <section style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 20, padding: '42px 0 15px', marginTop: 45, borderTop: '1px solid rgba(32,35,48,.15)' }}>
          <div><div className="eyebrow">Your evening, sorted</div><p style={{ font: '700 clamp(21px,3vw,32px) var(--app-font-serif)', margin: '11px 0 0' }}>Pick the film. We’ll save your seat.</p></div>
          <Link href="#movies-heading" className="primary-button" data-testid="link-explore-films">Explore films <ArrowRight size={16} /></Link>
        </section>
      </PageWrap>
    </SiteShell>
  );
}
