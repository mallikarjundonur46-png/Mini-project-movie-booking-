import { Link, useParams } from 'wouter';
import { ArrowLeft, CalendarDays, Check, Clock3, RotateCw, TicketCheck } from 'lucide-react';
import { useGetBooking } from '@workspace/api-client-react';
import { PageWrap, SiteShell } from '@/components/SiteShell';
import { formatBookingDate, formatCurrency, formatShowtime } from '@/lib/format';

export default function BookingPage() {
  const { code = '' } = useParams<{ code: string }>();
  const bookingQuery = useGetBooking(decodeURIComponent(code));
  const booking = bookingQuery.data;
  const dateLabel = booking?.createdAt ? formatBookingDate(booking.createdAt) : '';

  return (
    <SiteShell>
      <PageWrap>
        {bookingQuery.isLoading && <div className="confirmation" aria-label="Loading booking"><div className="skeleton" style={{ height: 180 }} /><div className="skeleton" style={{ height: 270 }} /></div>}
        {bookingQuery.isError && <div className="confirmation error-state" role="alert" data-testid="status-booking-load-error"><h3>We couldn’t find that booking.</h3><p>The confirmation link may be incomplete, or the server is having a moment.</p><button className="primary-button" onClick={() => void bookingQuery.refetch()} data-testid="button-retry-booking"><RotateCw size={15} /> Try again</button><div style={{ marginTop: 20 }}><Link href="/" className="nav-link" data-testid="link-home-error"><ArrowLeft size={15} /> Back to films</Link></div></div>}
        {!bookingQuery.isLoading && !bookingQuery.isError && booking && <article className="confirmation fade-in">
          <div className="confirm-top">
            <div className="eyebrow" style={{ color: '#f1d995' }}><Check size={14} /> You’re all set</div>
            <h1>It’s a date.</h1>
            <p>Your seats are saved. Just bring yourself (and whoever you’re taking).</p>
          </div>
          <div className="ticket-card">
            <div className="ticket-code" data-testid="text-booking-code">BOOKING · {booking.code}</div>
            <div style={{ marginTop: 14, font: '700 clamp(29px,5vw,43px) var(--app-font-serif)', letterSpacing: '-.04em' }} data-testid="text-booking-movie">{booking.movieTitle}</div>
            <div className="ticket-grid">
               <div className="ticket-field"><span><CalendarDays size={12} style={{ verticalAlign: 'middle', marginRight: 5 }} />Showtime</span><strong data-testid="text-booking-showtime">{formatShowtime(booking.showtime)}</strong></div>
              <div className="ticket-field"><span><TicketCheck size={12} style={{ verticalAlign: 'middle', marginRight: 5 }} />Seats</span><strong data-testid="text-booking-seats">{booking.seats.join(', ')}</strong></div>
              <div className="ticket-field"><span>Booking name</span><strong data-testid="text-booking-customer">{booking.customerName}</strong></div>
              <div className="ticket-field"><span><Clock3 size={12} style={{ verticalAlign: 'middle', marginRight: 5 }} />Reserved</span><strong data-testid="text-booking-created">{dateLabel}</strong></div>
            </div>
             <div className="ticket-bottom"><span style={{ fontSize: 12, color: '#777169' }}>Total · {booking.seats.length} {booking.seats.length === 1 ? 'ticket' : 'tickets'}</span><strong data-testid="text-booking-total">{formatCurrency(Number(booking.totalCost))}</strong></div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '21px 0', gap: 15 }}>
            <span style={{ font: '10px var(--app-font-mono)', textTransform: 'uppercase', letterSpacing: '.1em', color: '#777169' }}>Keep this code handy at the door</span>
            <Link href="/" className="primary-button" data-testid="link-book-another"><ArrowLeft size={15} /> Find another film</Link>
          </div>
        </article>}
      </PageWrap>
    </SiteShell>
  );
}
