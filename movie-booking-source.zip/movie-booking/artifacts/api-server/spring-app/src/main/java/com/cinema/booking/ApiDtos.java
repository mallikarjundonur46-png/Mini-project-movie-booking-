package com.cinema.booking;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

public final class ApiDtos {
  private ApiDtos() {}

  public record Movie(
      Long id,
      String title,
      String genre,
      String posterImage,
      BigDecimal ticketPrice,
      int durationMinutes,
      String synopsis,
      List<String> showtimes) {}

  public record Seat(String label, boolean available) {}

  public record BookingInput(
      @NotNull Long movieId,
      @NotBlank String showtime,
      @NotBlank String customerName,
      @NotEmpty List<@NotBlank String> seats) {}

  public record Booking(
      String code,
      Long movieId,
      String movieTitle,
      String showtime,
      String customerName,
      List<String> seats,
      BigDecimal ticketPrice,
      BigDecimal totalCost,
      String createdAt) {}
}
