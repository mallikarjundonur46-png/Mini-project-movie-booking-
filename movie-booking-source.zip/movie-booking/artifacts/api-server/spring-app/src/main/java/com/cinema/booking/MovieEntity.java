package com.cinema.booking;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name = "movies")
public class MovieEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, unique = true)
  private String title;

  @Column(nullable = false)
  private String genre;

  @Column(name = "poster_image", nullable = false, length = 1000)
  private String posterImage;

  @Column(name = "ticket_price", nullable = false, precision = 8, scale = 2)
  private BigDecimal ticketPrice;

  @Column(name = "duration_minutes", nullable = false)
  private int durationMinutes;

  @Column(nullable = false, length = 2000)
  private String synopsis;

  protected MovieEntity() {}

  public MovieEntity(
      String title,
      String genre,
      String posterImage,
      BigDecimal ticketPrice,
      int durationMinutes,
      String synopsis) {
    this.title = title;
    this.genre = genre;
    this.posterImage = posterImage;
    this.ticketPrice = ticketPrice;
    this.durationMinutes = durationMinutes;
    this.synopsis = synopsis;
  }

  public Long getId() { return id; }
  public String getTitle() { return title; }
  public String getGenre() { return genre; }
  public String getPosterImage() { return posterImage; }
  public BigDecimal getTicketPrice() { return ticketPrice; }
  public int getDurationMinutes() { return durationMinutes; }
  public String getSynopsis() { return synopsis; }
  public void setPosterImage(String posterImage) { this.posterImage = posterImage; }
}
