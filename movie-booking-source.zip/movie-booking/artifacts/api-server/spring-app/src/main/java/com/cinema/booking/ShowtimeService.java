package com.cinema.booking;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ShowtimeService {
  private static final ZoneId CINEMA_ZONE = ZoneId.of("Asia/Kolkata");
  private static final List<LocalTime> SCREENING_TIMES = List.of(
      LocalTime.of(11, 30),
      LocalTime.of(14, 45),
      LocalTime.of(18, 0),
      LocalTime.of(21, 15));

  public List<String> upcomingShowtimes() {
    OffsetDateTime now = OffsetDateTime.now(CINEMA_ZONE);
    List<String> showtimes = new ArrayList<>();
    for (int day = 0; day < 7; day++) {
      LocalDate date = LocalDate.now(CINEMA_ZONE).plusDays(day);
      for (LocalTime time : SCREENING_TIMES) {
        OffsetDateTime screening = OffsetDateTime.of(date, time, CINEMA_ZONE.getRules().getOffset(date.atTime(time)));
        if (screening.isAfter(now.plusMinutes(30))) {
          showtimes.add(screening.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        }
      }
    }
    return showtimes;
  }

  public boolean isUpcomingShowtime(String showtime) {
    return upcomingShowtimes().contains(showtime);
  }
}
