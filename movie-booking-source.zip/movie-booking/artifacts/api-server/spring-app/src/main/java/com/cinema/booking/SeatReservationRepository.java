package com.cinema.booking;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeatReservationRepository extends JpaRepository<SeatReservationEntity, Long> {
  List<SeatReservationEntity> findByMovie_IdAndShowtime(Long movieId, String showtime);
}
