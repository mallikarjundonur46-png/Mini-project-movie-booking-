package com.cinema.booking;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BookingService {
  private static final Set<String> ROWS = Set.of("A", "B", "C", "D", "E", "F", "G", "H");
  private static final int SEATS_PER_ROW = 10;

  private final MovieRepository movieRepository;
  private final BookingRepository bookingRepository;
  private final SeatReservationRepository reservationRepository;
  private final ShowtimeService showtimeService;

  public BookingService(
      MovieRepository movieRepository,
      BookingRepository bookingRepository,
      SeatReservationRepository reservationRepository,
      ShowtimeService showtimeService) {
    this.movieRepository = movieRepository;
    this.bookingRepository = bookingRepository;
    this.reservationRepository = reservationRepository;
    this.showtimeService = showtimeService;
  }

  @Transactional
  public ApiDtos.Booking create(ApiDtos.BookingInput input) {
    MovieEntity movie = movieRepository.findById(input.movieId())
        .orElseThrow(() -> new ResourceNotFoundException("Movie not found."));
    if (!showtimeService.isUpcomingShowtime(input.showtime())) {
      throw new InvalidBookingException("Choose one of the upcoming showtimes.");
    }
    List<String> normalizedSeats = input.seats().stream()
        .map(seat -> seat.trim().toUpperCase(Locale.ROOT))
        .sorted()
        .toList();
    if (normalizedSeats.size() != new HashSet<>(normalizedSeats).size()) {
      throw new InvalidBookingException("A seat can only be selected once.");
    }
    if (normalizedSeats.stream().anyMatch(seat -> !isValidSeat(seat))) {
      throw new InvalidBookingException("One or more seat labels are invalid.");
    }
    Set<String> reservedSeats = new HashSet<>(reservationRepository
        .findByMovie_IdAndShowtime(movie.getId(), input.showtime()).stream()
        .map(SeatReservationEntity::getSeatLabel)
        .toList());
    if (normalizedSeats.stream().anyMatch(reservedSeats::contains)) {
      throw new SeatUnavailableException("One or more selected seats have just been booked. Please choose different seats.");
    }

    BigDecimal total = movie.getTicketPrice().multiply(BigDecimal.valueOf(normalizedSeats.size()));
    BookingEntity booking = new BookingEntity(
        "CIN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT),
        movie,
        input.showtime(),
        input.customerName().trim(),
        movie.getTicketPrice(),
        total,
        OffsetDateTime.now(ZoneId.of("Asia/Kolkata")));
    normalizedSeats.forEach(label ->
        booking.addReservation(new SeatReservationEntity(movie, input.showtime(), label)));
    try {
      return toDto(bookingRepository.saveAndFlush(booking));
    } catch (DataIntegrityViolationException exception) {
      throw new SeatUnavailableException("One or more selected seats have just been booked. Please choose different seats.");
    }
  }

  @Transactional(readOnly = true)
  public ApiDtos.Booking getByCode(String code) {
    BookingEntity booking = bookingRepository.findByCode(code.toUpperCase(Locale.ROOT))
        .orElseThrow(() -> new ResourceNotFoundException("Booking not found."));
    return toDto(booking);
  }

  private ApiDtos.Booking toDto(BookingEntity booking) {
    List<String> seats = booking.getReservations().stream()
        .map(SeatReservationEntity::getSeatLabel)
        .sorted(Comparator.naturalOrder())
        .toList();
    return new ApiDtos.Booking(
        booking.getCode(),
        booking.getMovie().getId(),
        booking.getMovie().getTitle(),
        booking.getShowtime(),
        booking.getCustomerName(),
        seats,
        booking.getTicketPrice(),
        booking.getTotalCost(),
        booking.getCreatedAt().toString());
  }

  private boolean isValidSeat(String seat) {
    if (seat.length() < 2 || seat.length() > 3) return false;
    String row = seat.substring(0, 1);
    if (!ROWS.contains(row)) return false;
    try {
      int number = Integer.parseInt(seat.substring(1));
      return number >= 1 && number <= SEATS_PER_ROW;
    } catch (NumberFormatException exception) {
      return false;
    }
  }
}
