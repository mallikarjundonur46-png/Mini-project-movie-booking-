package com.cinema.booking;

import static com.cinema.booking.ApiDtos.Movie;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class MovieController {
  private final MovieCatalogService catalogService;

  public MovieController(MovieCatalogService catalogService) {
    this.catalogService = catalogService;
  }

  @GetMapping("/healthz")
  public HealthStatus health() {
    return new HealthStatus("ok");
  }

  @GetMapping("/movies")
  public List<Movie> listMovies() {
    return catalogService.listMovies();
  }

  @GetMapping("/movies/{movieId}/seats")
  public List<ApiDtos.Seat> getSeats(
      @PathVariable Long movieId,
      @RequestParam String showtime) {
    return catalogService.getSeats(movieId, showtime);
  }

  public record HealthStatus(String status) {}
}
