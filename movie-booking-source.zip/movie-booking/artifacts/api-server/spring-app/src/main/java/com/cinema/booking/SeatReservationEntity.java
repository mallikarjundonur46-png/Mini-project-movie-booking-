package com.cinema.booking;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(
    name = "seat_reservations",
    uniqueConstraints = @UniqueConstraint(
        name = "uq_movie_showtime_seat",
        columnNames = {"movie_id", "showtime", "seat_label"}))
public class SeatReservationEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "movie_id", nullable = false)
  private MovieEntity movie;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "booking_id", nullable = false)
  private BookingEntity booking;

  @Column(nullable = false, length = 60)
  private String showtime;

  @Column(name = "seat_label", nullable = false, length = 4)
  private String seatLabel;

  protected SeatReservationEntity() {}

  public SeatReservationEntity(MovieEntity movie, String showtime, String seatLabel) {
    this.movie = movie;
    this.showtime = showtime;
    this.seatLabel = seatLabel;
  }

  public void setBooking(BookingEntity booking) { this.booking = booking; }
  public String getSeatLabel() { return seatLabel; }
}
