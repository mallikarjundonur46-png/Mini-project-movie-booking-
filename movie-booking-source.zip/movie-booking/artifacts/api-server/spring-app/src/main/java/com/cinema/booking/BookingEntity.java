package com.cinema.booking;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "bookings")
public class BookingEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, unique = true, length = 20)
  private String code;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "movie_id", nullable = false)
  private MovieEntity movie;

  @Column(nullable = false, length = 60)
  private String showtime;

  @Column(name = "customer_name", nullable = false, length = 120)
  private String customerName;

  @Column(name = "ticket_price", nullable = false, precision = 8, scale = 2)
  private BigDecimal ticketPrice;

  @Column(name = "total_cost", nullable = false, precision = 10, scale = 2)
  private BigDecimal totalCost;

  @Column(name = "created_at", nullable = false)
  private OffsetDateTime createdAt;

  @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL, orphanRemoval = true)
  private List<SeatReservationEntity> reservations = new ArrayList<>();

  protected BookingEntity() {}

  public BookingEntity(
      String code,
      MovieEntity movie,
      String showtime,
      String customerName,
      BigDecimal ticketPrice,
      BigDecimal totalCost,
      OffsetDateTime createdAt) {
    this.code = code;
    this.movie = movie;
    this.showtime = showtime;
    this.customerName = customerName;
    this.ticketPrice = ticketPrice;
    this.totalCost = totalCost;
    this.createdAt = createdAt;
  }

  public void addReservation(SeatReservationEntity reservation) {
    reservations.add(reservation);
    reservation.setBooking(this);
  }

  public Long getId() { return id; }
  public String getCode() { return code; }
  public MovieEntity getMovie() { return movie; }
  public String getShowtime() { return showtime; }
  public String getCustomerName() { return customerName; }
  public BigDecimal getTicketPrice() { return ticketPrice; }
  public BigDecimal getTotalCost() { return totalCost; }
  public OffsetDateTime getCreatedAt() { return createdAt; }
  public List<SeatReservationEntity> getReservations() { return reservations; }
}
