package com.cinema.booking;

import jakarta.validation.ConstraintViolationException;
import java.util.Map;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

class ResourceNotFoundException extends RuntimeException {
  ResourceNotFoundException(String message) { super(message); }
}

class InvalidBookingException extends RuntimeException {
  InvalidBookingException(String message) { super(message); }
}

class SeatUnavailableException extends RuntimeException {
  SeatUnavailableException(String message) { super(message); }
}

@RestControllerAdvice
public class ApiExceptions {
  @ExceptionHandler(ResourceNotFoundException.class)
  ResponseEntity<Map<String, String>> notFound(RuntimeException exception) {
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", exception.getMessage()));
  }

  @ExceptionHandler(SeatUnavailableException.class)
  ResponseEntity<Map<String, String>> seatUnavailable(RuntimeException exception) {
    return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", exception.getMessage()));
  }

  @ExceptionHandler({InvalidBookingException.class, MethodArgumentNotValidException.class, ConstraintViolationException.class})
  ResponseEntity<Map<String, String>> invalidRequest(Exception exception) {
    String message = exception instanceof InvalidBookingException
        ? exception.getMessage()
        : "Please check the booking details and try again.";
    return ResponseEntity.badRequest().body(Map.of("error", message));
  }

  @ExceptionHandler(DataIntegrityViolationException.class)
  ResponseEntity<Map<String, String>> dataConflict(DataIntegrityViolationException exception) {
    return ResponseEntity.status(HttpStatus.CONFLICT)
        .body(Map.of("error", "One or more selected seats have just been booked. Please choose different seats."));
  }
}
