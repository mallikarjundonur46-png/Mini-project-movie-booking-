package com.cinema.booking;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface MovieRepository extends JpaRepository<MovieEntity, Long> {
  Optional<MovieEntity> findByTitle(String title);
}
