package com.cinema.booking;

import static com.cinema.booking.ApiDtos.Movie;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

@Service
public class MovieCatalogService implements CommandLineRunner {
  private static final List<String> ROWS = List.of("A", "B", "C", "D", "E", "F", "G", "H");
  private static final int SEATS_PER_ROW = 10;

  private final MovieRepository movieRepository;
  private final SeatReservationRepository reservationRepository;
  private final ShowtimeService showtimeService;

  public MovieCatalogService(
      MovieRepository movieRepository,
      SeatReservationRepository reservationRepository,
      ShowtimeService showtimeService) {
    this.movieRepository = movieRepository;
    this.reservationRepository = reservationRepository;
    this.showtimeService = showtimeService;
  }

  public List<Movie> listMovies() {
    List<String> showtimes = showtimeService.upcomingShowtimes();
    return movieRepository.findAll().stream()
        .map(movie -> new Movie(
            movie.getId(),
            movie.getTitle(),
            movie.getGenre(),
            movie.getPosterImage(),
            movie.getTicketPrice(),
            movie.getDurationMinutes(),
            movie.getSynopsis(),
            showtimes))
        .toList();
  }

  public List<ApiDtos.Seat> getSeats(Long movieId, String showtime) {
    MovieEntity movie = movieRepository.findById(movieId)
        .orElseThrow(() -> new ResourceNotFoundException("Movie not found."));
    if (!showtimeService.isUpcomingShowtime(showtime)) {
      throw new InvalidBookingException("Choose one of the upcoming showtimes.");
    }
    Set<String> reserved = reservationRepository
        .findByMovie_IdAndShowtime(movie.getId(), showtime).stream()
        .map(SeatReservationEntity::getSeatLabel)
        .collect(Collectors.toSet());
    List<ApiDtos.Seat> seats = new ArrayList<>();
    for (String row : ROWS) {
      for (int number = 1; number <= SEATS_PER_ROW; number++) {
        String label = row + number;
        seats.add(new ApiDtos.Seat(label, !reserved.contains(label)));
      }
    }
    return seats;
  }

  @Override
  public void run(String... args) {
    if (movieRepository.count() == 0) {
      movieRepository.saveAll(List.of(
          new MovieEntity(
              "Kantara",
              "Action · Drama",
              "/posters/kantara.svg",
              new BigDecimal("320.00"),
              148,
              "A forest official and a village guardian collide over land, tradition, and the forces that protect their home."),
          new MovieEntity(
              "KGF Chapter 2",
              "Action · Crime",
              "https://image.tmdb.org/t/p/w500/ltHlJwvxKv7d0ooCiKSAvfwV9tX.jpg",
              new BigDecimal("350.00"),
              168,
              "Rocky rises to power in the gold fields, facing enemies who want to take his empire from him."),
          new MovieEntity(
              "Interstellar",
              "Sci-Fi · Adventure",
              "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg",
              new BigDecimal("400.00"),
              169,
              "A team travels beyond this galaxy to discover whether mankind has a future among the stars.")
      ));
      return;
    }
    movieRepository.findByTitle("Kantara").ifPresent(movie -> {
      movie.setPosterImage("/posters/kantara.svg");
      movieRepository.save(movie);
    });
  }
}
