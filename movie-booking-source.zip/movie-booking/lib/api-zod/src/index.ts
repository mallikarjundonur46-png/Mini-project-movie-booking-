export * from "./generated/api";
export {
  type Booking,
  type BookingInput,
  type HealthStatus,
  type Movie,
  type Seat,
} from "./generated/types";
